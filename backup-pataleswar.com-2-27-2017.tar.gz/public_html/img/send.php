<?php	
require "class.phpmailer.php"; 
$mail = new PHPMailer(); 
 

$mail->IsSMTP(); 
$mail->SMTPAuth= true; 
$mail->Port= 995; 
$mail->Host= "cpanel.freehosting.com"; // SMTP server 
$mail->Username= "contactus@pataleswar.com"; // SMTP account username
$mail->Password= "Rupesh#123"; // SMTP account password

$mail->From= "contactus@pataleswar.com"; 
$mail->FromName= "Customers"; 
$mail->AddAddress("inquery@pataleswar.com"); // Receiving Mail ID, it can be either domain mail id (or ) any other mail id i.e., gmail id

$mail->Subject="Websites's customers details"; 
$mail->AltBody= " "; 
$mail->WordWrap= 80; 

$name=$_POST['name'];
$subject=$_POST['subject'];
$email=$_POST['email'];
$message=$_POST['message'];

$body= "Name: {$name} <br>".
 		"email: {$email}<br>".
		"subject: {$subject}<br>".
		"message: {$message}<br>".
		"--------------------------------<br>";
 
 
$mail->MsgHTML($body); 
$mail->IsHTML(true); 
if(!$mail->send())
{
echo "Mailer Error: " . $mail->ErrorInfo;
}
else {
 echo "";
	include'thankyou.php';
 
}
?>