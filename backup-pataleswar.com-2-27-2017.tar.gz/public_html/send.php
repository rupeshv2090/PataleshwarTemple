<?php	
require "class.phpmailer.php"; 
$mail = new PHPMailer(); 
 
$mail->SMTPDebug = 3; 
$mail->IsSMTP(); 
$mail->SMTPAuth= true; 
$mail->Port= 587; 
$mail->Host= "smtp.gmail.com"; // SMTP server 
$mail->Username= "rupeshvm.977@gmail.com"; // SMTP account username
$mail->Password= "Rupesh#20490"; // SMTP account password
$mail->SMTPSecure = "tls"; 
$mail->From= "rupeshvm.977@gmail.com"; 
$mail->FromName= "Rupesh"; 
$mail->AddAddress("rupeshvm.977@gmail.com","Rupesh"); // Receiving Mail ID, it can be either domain mail id (or ) any other mail id i.e., gmail id
$mail->isHTML(true);
$mail->Subject="Websites's customers details"; 

$mail->WordWrap= 80; 

$name=$_POST['name'];
$subject=$_POST['subject'];
$email=$_POST['email'];
$message=$_POST['message'];

$body= "Name: {$name} <br>".
 		"email: {$email}<br>".
		"subject: {$subject}<br>".
		"message: {$message}<br>".
		"--------------------------------<br>";
 
 
$mail->MsgHTML($body); 
$mail->IsHTML(true); 
if(!$mail->send())
{
echo "Mailer Error: " . $mail->ErrorInfo;
}
else {
 echo "";
	include'thankyou.php';
 
}
?>