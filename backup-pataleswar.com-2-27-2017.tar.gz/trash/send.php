<?php	
// require_once ("class.phpmailer.php"); 
require '../PHPMailerAutoload.php';
$mail = new PHPMailer; 
 

$mail->IsSMTP(); 
$mail->SMTPAuth= true; 
$mail->SMTPSecure = 'ssl'; 
$mail->Host= "smtp.gmail.com"; // SMTP server 
$mail->Port= 587;
$mail->IsHTML(true);
$mail->Username= "pataleswar.lakhanakhera@gmail.com"; // SMTP account username
$mail->Password= "lakhanakhera.com"; // SMTP account password

$mail->From= "pataleswar.lakhanakhera@gmail.com"; 
$mail->FromName= "Customers"; 
$mail->AddAddress("rupeshvm.977@gmail.com"); // Receiving Mail ID, it can be either domain mail id (or ) any other mail id i.e., gmail id

$mail->Subject="Websites's customers details"; 
$mail->AltBody= " "; 
$mail->WordWrap= 80; 

$name=$_POST['name'];
$subject=$_POST['subject'];
$email=$_POST['email'];
$message=$_POST['message'];

$body= "Name: {$name} <br>".
 		"email: {$email}<br>".
		"subject: {$subject}<br>".
		"message: {$message}<br>".
		"--------------------------------<br>";
 
 
$mail->MsgHTML($body); 
$mail->IsHTML(true); 
if(!$mail->send())
{
echo "Mailer Error: " . $mail->ErrorInfo;
}
else {
 echo "Send Successfully.";
	include'thankyou.php';
 
}
?>